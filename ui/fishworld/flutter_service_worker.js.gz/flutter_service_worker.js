'use strict';
const MANIFEST = 'flutter-app-manifest';
const TEMP = 'flutter-temp-cache';
const CACHE_NAME = 'flutter-app-cache';

const RESOURCES = {"assets/AssetManifest.bin": "f4eaaf1078946925e0fab08e227504af",
"assets/AssetManifest.bin.json": "676a6167b26f6984ed86b097a15a0e4b",
"assets/AssetManifest.bin.json.gz": "1e56cc2b4f4807534daa9251e52ebdac",
"assets/AssetManifest.json": "28a396cb3eb45912d56791456c470a95",
"assets/assets/avatar.png": "2358c91fd3b128db1c3095735c4c47be",
"assets/assets/data/diary.json": "df419f9da1b4774cda9313d596ccceda",
"assets/assets/data/fish_snapshot.json": "0b878700ef66d887e8becf8d64c6e639",
"assets/assets/data/fish_snapshot.json.bak-before-memory-correction-20261109": "2dd204524f9978c3464f1a45836e92e4",
"assets/assets/data/fish_snapshot.json.gz": "914495c40253a0fca74240e9fb4b335a",
"assets/assets/data/gallery.json": "599f6d74406c30ede527706dc11a2b1f",
"assets/assets/data/gallery.json.gz": "951905fb96807b50c1cc184a65b65f50",
"assets/assets/data/growth.json": "a27ec4ec6556e8fb4e5bcca7fcfc6ed7",
"assets/assets/data/links.json": "20f422352a065fecc4c915dda369704c",
"assets/assets/data/memory.json": "eced289655e4ef5b25079c105e424810",
"assets/assets/data/memory.json.gz": "0cabe84baaf9854fbe34f6073d76171c",
"assets/assets/data/notes.json": "5216ee320c97b7f5d1054e82374a2149",
"assets/assets/data/notes.json.gz": "b35f572f260556e8a9952a1b463072dd",
"assets/assets/data/wish.json": "20f422352a065fecc4c915dda369704c",
"assets/assets/mascot.png": "c9410a87864e60a1c0716eb8f6830191",
"assets/assets/whale-logo.png": "a985b822abdf758c145c2d9a1e4e9265",
"assets/FontManifest.json": "7b2a36307916a9721811788013e65289",
"assets/fonts/MaterialIcons-Regular.otf": "a4e6c18ea6a9ec06f1c784c96e28a248",
"assets/NOTICES": "3b471141e38667296655aae7f0ac1d68",
"assets/shaders/ink_sparkle.frag": "ecc85a2e95f5e9f53123dcaf8cb9b6ce",
"canvaskit/canvaskit.js": "728b2d477d9b8c14593d4f9b82b484f3",
"canvaskit/canvaskit.js.gz": "2e29a2901f7d3d7e337cee2c3d7a0da6",
"canvaskit/canvaskit.js.symbols": "bdcd3835edf8586b6d6edfce8749fb77",
"canvaskit/canvaskit.wasm": "7a3f4ae7d65fc1de6a6e7ddd3224bc93",
"canvaskit/canvaskit.wasm.gz": "cf41b47f2180ab02bedb558b8f4e9ddf",
"canvaskit/chromium/canvaskit.js": "8191e843020c832c9cf8852a4b909d4c",
"canvaskit/chromium/canvaskit.js.symbols": "b61b5f4673c9698029fa0a746a9ad581",
"canvaskit/chromium/canvaskit.wasm": "f504de372e31c8031018a9ec0a9ef5f0",
"canvaskit/skwasm.js": "ea559890a088fe28b4ddf70e17e60052",
"canvaskit/skwasm.js.symbols": "e72c79950c8a8483d826a7f0560573a1",
"canvaskit/skwasm.wasm": "39dd80367a4e71582d234948adc521c0",
"favicon.png": "a985b822abdf758c145c2d9a1e4e9265",
"flutter.js": "83d881c1dbb6d6bcd6b42e274605b69c",
"flutter.js.gz": "2e4b5598efbff6f50c3eee216258127d",
"flutter_bootstrap.js": "89ae0837fb3c65c0e04e6b3fd65d9439",
"flutter_bootstrap.js.gz": "9f88665c47c36976b38792e80375d6bd",
"flutter_service_worker.js.gz": "cde6655b20cb7af7b04b560e37462fdc",
"icons/Icon-192.png": "ac9a721a12bbc803b44f645561ecb1e1",
"icons/Icon-512.png": "96e752610906ba2a93c65f8abe1645f1",
"icons/Icon-maskable-192.png": "c457ef57daa1d16f64b27b786ec2ea3c",
"icons/Icon-maskable-512.png": "301a7604d45b3e739efc881eb04896ea",
"index.html": "5ce6dab222abfd8174a93781dc992ebc",
"/": "5ce6dab222abfd8174a93781dc992ebc",
"index.html.bak-fishworld-naming-20261109": "18a3a1b5c3973f3018bf8fdbb5e72c87",
"main.dart.js": "c9f024c61771d053d4511364535579ae",
"main.dart.js.gz": "fb845045ae19e93f906ba799a71da3ae",
"manifest.json": "0da9510144aeb859a40e4d62cd1caf7e",
"manifest.json.bak-fishworld-naming-20261109": "6f498a0c7c107d052e4d231e390d6cda",
"splash.css": "e0a8d833addf0f91d6f52c4ddb96f15a",
"splash.js": "121a4c11b0340028632d9232377b1d39",
"version.json": "97ae1a2fa56a94de0dffccc302519ebd"};
// The application shell files that are downloaded before a service worker can
// start.
const CORE = ["main.dart.js",
"index.html",
"flutter_bootstrap.js",
"assets/AssetManifest.bin.json",
"assets/FontManifest.json"];

// During install, the TEMP cache is populated with the application shell files.
self.addEventListener("install", (event) => {
  self.skipWaiting();
  return event.waitUntil(
    caches.open(TEMP).then((cache) => {
      return cache.addAll(
        CORE.map((value) => new Request(value, {'cache': 'reload'})));
    })
  );
});
// During activate, the cache is populated with the temp files downloaded in
// install. If this service worker is upgrading from one with a saved
// MANIFEST, then use this to retain unchanged resource files.
self.addEventListener("activate", function(event) {
  return event.waitUntil(async function() {
    try {
      var contentCache = await caches.open(CACHE_NAME);
      var tempCache = await caches.open(TEMP);
      var manifestCache = await caches.open(MANIFEST);
      var manifest = await manifestCache.match('manifest');
      // When there is no prior manifest, clear the entire cache.
      if (!manifest) {
        await caches.delete(CACHE_NAME);
        contentCache = await caches.open(CACHE_NAME);
        for (var request of await tempCache.keys()) {
          var response = await tempCache.match(request);
          await contentCache.put(request, response);
        }
        await caches.delete(TEMP);
        // Save the manifest to make future upgrades efficient.
        await manifestCache.put('manifest', new Response(JSON.stringify(RESOURCES)));
        // Claim client to enable caching on first launch
        self.clients.claim();
        return;
      }
      var oldManifest = await manifest.json();
      var origin = self.location.origin;
      for (var request of await contentCache.keys()) {
        var key = request.url.substring(origin.length + 1);
        if (key == "") {
          key = "/";
        }
        // If a resource from the old manifest is not in the new cache, or if
        // the MD5 sum has changed, delete it. Otherwise the resource is left
        // in the cache and can be reused by the new service worker.
        if (!RESOURCES[key] || RESOURCES[key] != oldManifest[key]) {
          await contentCache.delete(request);
        }
      }
      // Populate the cache with the app shell TEMP files, potentially overwriting
      // cache files preserved above.
      for (var request of await tempCache.keys()) {
        var response = await tempCache.match(request);
        await contentCache.put(request, response);
      }
      await caches.delete(TEMP);
      // Save the manifest to make future upgrades efficient.
      await manifestCache.put('manifest', new Response(JSON.stringify(RESOURCES)));
      // Claim client to enable caching on first launch
      self.clients.claim();
      return;
    } catch (err) {
      // On an unhandled exception the state of the cache cannot be guaranteed.
      console.error('Failed to upgrade service worker: ' + err);
      await caches.delete(CACHE_NAME);
      await caches.delete(TEMP);
      await caches.delete(MANIFEST);
    }
  }());
});
// The fetch handler redirects requests for RESOURCE files to the service
// worker cache.
self.addEventListener("fetch", (event) => {
  if (event.request.method !== 'GET') {
    return;
  }
  var origin = self.location.origin;
  var key = event.request.url.substring(origin.length + 1);
  // Redirect URLs to the index.html
  if (key.indexOf('?v=') != -1) {
    key = key.split('?v=')[0];
  }
  if (event.request.url == origin || event.request.url.startsWith(origin + '/#') || key == '') {
    key = '/';
  }
  // If the URL is not the RESOURCE list then return to signal that the
  // browser should take over.
  if (!RESOURCES[key]) {
    return;
  }
  // If the URL is the index.html, perform an online-first request.
  if (key == '/') {
    return onlineFirst(event);
  }
  event.respondWith(caches.open(CACHE_NAME)
    .then((cache) =>  {
      return cache.match(event.request).then((response) => {
        // Either respond with the cached resource, or perform a fetch and
        // lazily populate the cache only if the resource was successfully fetched.
        return response || fetch(event.request).then((response) => {
          if (response && Boolean(response.ok)) {
            cache.put(event.request, response.clone());
          }
          return response;
        });
      })
    })
  );
});
self.addEventListener('message', (event) => {
  // SkipWaiting can be used to immediately activate a waiting service worker.
  // This will also require a page refresh triggered by the main worker.
  if (event.data === 'skipWaiting') {
    self.skipWaiting();
    return;
  }
  if (event.data === 'downloadOffline') {
    downloadOffline();
    return;
  }
});
// Download offline will check the RESOURCES for all files not in the cache
// and populate them.
async function downloadOffline() {
  var resources = [];
  var contentCache = await caches.open(CACHE_NAME);
  var currentContent = {};
  for (var request of await contentCache.keys()) {
    var key = request.url.substring(origin.length + 1);
    if (key == "") {
      key = "/";
    }
    currentContent[key] = true;
  }
  for (var resourceKey of Object.keys(RESOURCES)) {
    if (!currentContent[resourceKey]) {
      resources.push(resourceKey);
    }
  }
  return contentCache.addAll(resources);
}
// Attempt to download the resource online before falling back to
// the offline cache.
function onlineFirst(event) {
  return event.respondWith(
    fetch(event.request).then((response) => {
      return caches.open(CACHE_NAME).then((cache) => {
        cache.put(event.request, response.clone());
        return response;
      });
    }).catch((error) => {
      return caches.open(CACHE_NAME).then((cache) => {
        return cache.match(event.request).then((response) => {
          if (response != null) {
            return response;
          }
          throw error;
        });
      });
    })
  );
}
